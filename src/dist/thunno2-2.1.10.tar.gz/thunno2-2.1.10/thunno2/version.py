"""
This file contains only one constant - the version

That's it!
"""

THUNNO_VERSION = "2.1.10"
