from thunno2 import (
    autoexplanation,
    codepage,
    commands,
    constants,
    dictionary,
    flags,
    helpers,
    interpreter,
    lexer,
    run,
    tests,
    tokens,
    version
)
